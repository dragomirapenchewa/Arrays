﻿using System;
using System.Collections.Generic;
using System.Data.SqlTypes;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Zad1
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Wuwedi broi na el.:");
            int n = int.Parse(Console.ReadLine());

            int[] numbers = new int[n];

            for (int i = 0; i < n; i++)
            {
                numbers[i] = int.Parse(Console.ReadLine());
            }

            Console.WriteLine("Wuwedi index na bombickata: ");
            int bombIndex = int.Parse(Console.ReadLine());
            Console.WriteLine("Wuwedi sila na bombichkata: ");
            int bombStrength = int.Parse(Console.ReadLine());

            int bombValue = numbers[bombIndex];

            for (int i = Math.Max(0, bombIndex - bombStrength); i < Math.Min(n - 1, bombIndex + bombStrength); i++)
            {
                numbers[i] = 0;
            }

            int sum = 0;

            for (int i = 0;i < n; i++)
            {
                Console.WriteLine(numbers[i] + " ");
                sum += numbers[i];
            }

            Console.WriteLine($"Bombickata: {sum}");
        }
    }
}
